from flask import Flask, render_template, request
from data_fetcher import WeatherPredictor  # Import the WeatherPredictor class

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/weather', methods=['GET'])
def weather():
    city = request.args.get('city', 'London')  # Default to London if no city is provided
    predictor = WeatherPredictor("30f1c3915d984e7c9c5163956241409")  # Use your API key
    
    try:
        # Fetch weather data
        data = predictor.get_weather_data(city)
        
        if data:
            # Predict temperature based on arbitrary values for demonstration
            predicted_temp = predictor.predict_temperature(humidity=60, wind_kph=15)
            return render_template('weather.html', weather_data=data, predicted_temp=predicted_temp)
        else:
            return render_template('error.html', error="Could not fetch weather data")
    except Exception as e:
        return render_template('error.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True)


