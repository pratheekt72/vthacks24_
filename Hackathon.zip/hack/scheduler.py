import schedule
import time
from data_fetcher import get_weather_data, display_weather_data

def fetch_and_display_weather(city):
    """
    Fetch and display weather data for a specific city and send alerts if necessary.

    Args:
        city (str): The name of the city.
    """
    weather_data = get_weather_data(city)
    
    if weather_data:
        current = weather_data['current']
        condition = current['condition']['text']
        
        # Example: Alert for stormy weather
        if "storm" in condition.lower():
            print(f"Weather Alert: Storm detected in {city}!")
        
        # Display the weather data
        display_weather_data(weather_data)


def run_scheduler():
    """
    Set up the schedule to fetch weather data at regular intervals.
    """
    city = "London"  # Change this to the city you want to monitor

    # Schedule the fetch_and_display_weather function to run every 10 minutes
    schedule.every(10).minutes.do(fetch_and_display_weather, city=city)

    # Infinite loop to keep the scheduler running
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    print("Starting weather scheduler...")
    run_scheduler()


from notification import send_sms_alert

def check_weather_alert(weather_info):
    """
    Check if the current weather conditions require an alert and send an SMS if necessary.

    Args:
        weather_info (dict): The weather data dictionary.
    """
    if weather_info['weather'] in ['heavy rain', 'storm', 'snow']:
        alert_message = f"Weather Alert: Severe {weather_info['weather']} in {weather_info['city']}!"
        print(alert_message)

        # Send SMS notification
        send_sms_alert("+18044266004", alert_message)  # Replace with the recipient's phone number
    elif weather_info['temperature'] < 0:
        alert_message = f"Weather Alert: Freezing temperatures in {weather_info['city']}!"
        print(alert_message)

        # Send SMS notification
        send_sms_alert("+18044266004", alert_message)
