import requests
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

class WeatherPredictor:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "http://api.weatherapi.com/v1/current.json"
        self.model = None
        self._train_model()

    def get_weather_data(self, city):
        """Fetch current weather data for a given city."""
        url = f"{self.base_url}?key={self.api_key}&q={city}"
        try:
            response = requests.get(url)
            response.raise_for_status()  # Check if the request was successful (HTTP 200)
            data = response.json()
            return data
        except requests.exceptions.HTTPError as http_err:
            print(f"HTTP error occurred: {http_err}")
        except Exception as err:
            print(f"An error occurred: {err}")
        return None

    def display_weather_data(self, data):
        """Display the weather data in a readable format."""
        if data:
            location = data['location']
            current = data['current']
            print(f"Weather in {location['name']}, {location['region']}, {location['country']}")
            print(f"Temperature: {current['temp_c']}°C ({current['temp_f']}°F)")
            print(f"Condition: {current['condition']['text']}")
            print(f"Wind: {current['wind_mph']} mph ({current['wind_kph']} kph), Direction: {current['wind_dir']}")
            print(f"Humidity: {current['humidity']}%")
            print(f"Feels Like: {current['feelslike_c']}°C")
        else:
            print("No weather data available.")

    def _train_model(self):
        """Train a simple Linear Regression model."""
        # Example data for training
        data = {
            'temp_c': [15, 20, 25, 30, 35],
            'humidity': [80, 60, 50, 40, 30],
            'wind_kph': [10, 20, 15, 25, 30]
        }
        df = pd.DataFrame(data)

        X = df[['humidity', 'wind_kph']]
        y = df['temp_c']

        # Split the data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Initialize and train the linear regression model
        try:
            self.model = LinearRegression()
            self.model.fit(X_train, y_train)

            # Evaluate the model on the test data
            y_pred = self.model.predict(X_test)
            print(f"Model Mean Squared Error: {mean_squared_error(y_test, y_pred)}")
        except Exception as e:
            print(f"Error training model: {e}")

    def predict_temperature(self, humidity, wind_kph):
        """Predict temperature based on humidity and wind speed."""
        if self.model:
            try:
                input_data = pd.DataFrame([[humidity, wind_kph]], columns=['humidity', 'wind_kph'])
                prediction = self.model.predict(input_data)
                return prediction[0]
            except Exception as e:
                print(f"Error during prediction: {e}")
                return None
        else:
            print("Model not trained.")
            return None

    def check_for_disaster(self, data):
        """Check for potential natural disasters based on weather data."""
        if data:
            current = data['current']
            temp_c = current['temp_c']
            wind_kph = current['wind_kph']
            condition = current['condition']['text'].lower()

            # Custom logic to check for disasters
            if temp_c > 40 or wind_kph > 100 or "storm" in condition:
                print("Potential natural disaster warning!")
                return True  # Returning True to indicate disaster detected
            else:
                print("No natural disaster detected.")
                return False  # No disaster
        else:
            print("No weather data available.")
            return False
