from twilio.rest import Client
from config import TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER

def send_sms_alert(to_phone_number, message):
    """
    Send an SMS alert using Twilio.

    Args:
        to_phone_number (str): The recipient's phone number.
        message (str): The message to send.
    """
    if not TWILIO_ACCOUNT_SID or not TWILIO_AUTH_TOKEN or not TWILIO_PHONE_NUMBER:
        print("Error: Twilio configuration is missing or incomplete.")
        return

    client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

    try:
        # Ensure that the phone number is in the correct format with country code (e.g., +1234567890)
        if not to_phone_number.startswith('+'):
            print("Error: Recipient phone number must include the country code (e.g., +1234567890).")
            return
        
        message = client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=to_phone_number
        )
        print(f"Message successfully sent to {to_phone_number}. Message SID: {message.sid}")
        
    except Exception as e:
        print(f"Failed to send message: {e}")
